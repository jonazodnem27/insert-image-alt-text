<?php

/**
 * Fired during plugin activation
 *
 * @link       https://jonmendoza.ph
 * @since      1.0.0
 *
 * @package    Insert_Image_Alt_Text
 * @subpackage Insert_Image_Alt_Text/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Insert_Image_Alt_Text
 * @subpackage Insert_Image_Alt_Text/includes
 * @author     Jon Vincent Mendoza <jonazodnem26@gmail.com>
 */
class Insert_Image_Alt_Text_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
